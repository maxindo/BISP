/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: radius
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hotspot_profiles`
--

DROP TABLE IF EXISTS `hotspot_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotspot_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(128) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `comment` text DEFAULT NULL,
  `rate_limit_value` varchar(32) DEFAULT NULL,
  `rate_limit_unit` varchar(10) DEFAULT NULL,
  `burst_limit_value` varchar(32) DEFAULT NULL,
  `burst_limit_unit` varchar(10) DEFAULT NULL,
  `session_timeout_value` int(11) DEFAULT NULL,
  `session_timeout_unit` varchar(10) DEFAULT NULL,
  `idle_timeout_value` int(11) DEFAULT NULL,
  `idle_timeout_unit` varchar(10) DEFAULT NULL,
  `limit_uptime_value` int(11) DEFAULT NULL,
  `limit_uptime_unit` varchar(10) DEFAULT NULL,
  `validity_value` int(11) DEFAULT NULL,
  `validity_unit` varchar(10) DEFAULT NULL,
  `shared_users` int(11) DEFAULT 1,
  `local_address` varchar(64) DEFAULT NULL,
  `remote_address` varchar(64) DEFAULT NULL,
  `dns_server` varchar(255) DEFAULT NULL,
  `parent_queue` varchar(64) DEFAULT NULL,
  `address_list` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupname` (`groupname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotspot_profiles`
--

LOCK TABLES `hotspot_profiles` WRITE;
/*!40000 ALTER TABLE `hotspot_profiles` DISABLE KEYS */;
INSERT INTO `hotspot_profiles` VALUES (1,'paket-2000','Paket-2000',NULL,'10','M',NULL,'K',NULL,'s',NULL,'s',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-08 14:57:46','2025-12-08 14:57:46');
/*!40000 ALTER TABLE `hotspot_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL DEFAULT 'secret',
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT 'RADIUS Client',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pppoe_profiles`
--

DROP TABLE IF EXISTS `pppoe_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pppoe_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(128) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `comment` text DEFAULT NULL,
  `rate_limit` varchar(128) DEFAULT NULL,
  `local_address` varchar(64) DEFAULT NULL,
  `remote_address` varchar(64) DEFAULT NULL,
  `dns_server` varchar(128) DEFAULT NULL,
  `parent_queue` varchar(128) DEFAULT NULL,
  `address_list` varchar(128) DEFAULT NULL,
  `bridge_learning` varchar(16) NOT NULL DEFAULT 'default',
  `use_mpls` varchar(16) NOT NULL DEFAULT 'default',
  `use_compression` varchar(16) NOT NULL DEFAULT 'default',
  `use_encryption` varchar(16) NOT NULL DEFAULT 'default',
  `only_one` varchar(16) NOT NULL DEFAULT 'default',
  `change_tcp_mss` varchar(16) NOT NULL DEFAULT 'default',
  `use_upnp` varchar(16) NOT NULL DEFAULT 'default',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupname` (`groupname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pppoe_profiles`
--

LOCK TABLES `pppoe_profiles` WRITE;
/*!40000 ALTER TABLE `pppoe_profiles` DISABLE KEYS */;
INSERT INTO `pppoe_profiles` VALUES (1,'silver','Silver',NULL,'10M/10M',NULL,'POOL-PPPoE',NULL,NULL,NULL,'default','default','default','default','default','default','default','2025-11-28 06:26:26','2025-11-28 06:26:26');
/*!40000 ALTER TABLE `pppoe_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(32) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctupdatetime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctinterval` int(12) DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(128) DEFAULT NULL,
  `connectinfo_stop` varchar(128) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `framedipv6address` varchar(45) NOT NULL DEFAULT '',
  `framedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `framedinterfaceid` varchar(44) NOT NULL DEFAULT '',
  `delegatedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `class` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `framedipv6address` (`framedipv6address`),
  KEY `framedipv6prefix` (`framedipv6prefix`),
  KEY `framedinterfaceid` (`framedinterfaceid`),
  KEY `delegatedipv6prefix` (`delegatedipv6prefix`),
  KEY `acctsessionid` (`acctsessionid`),
  KEY `acctsessiontime` (`acctsessiontime`),
  KEY `acctstarttime` (`acctstarttime`),
  KEY `acctinterval` (`acctinterval`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`),
  KEY `class` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
INSERT INTO `radacct` VALUES (1,'80200002','cf50c4a3827d48a6c0b64809ad62cc27','CVXKGT','','10.201.39.146','ether3-TO-LOCAL','Wireless-802.11','2025-12-08 08:17:15','2025-12-08 08:17:15','2025-12-08 08:18:15',NULL,60,'','','',149696,685899,'Income','9E:05:3C:09:B9:DA','Session-Timeout','','','192.168.15.254','','','','',NULL),(2,'80200003','5d5e46c9348ce99147a14822ad22c341','CVXKGT','','10.201.39.146','ether3-TO-LOCAL','Wireless-802.11','2025-12-08 08:18:39','2025-12-08 08:18:39','2025-12-08 08:19:39',NULL,60,'','','',73144,312835,'Income','9E:05:3C:09:B9:DA','Session-Timeout','','','192.168.15.254','','','','',NULL),(3,'80200009','388b083da82d6c20bfa79602880f5c2d','C5BAT','','10.201.39.146','ether3-TO-LOCAL','Wireless-802.11','2025-12-08 08:24:58','2025-12-08 08:24:58','2025-12-08 08:25:58',NULL,60,'','','',70899,112964,'Income','9E:05:3C:09:B9:DA','Session-Timeout','','','192.168.15.254','','','','',NULL);
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES (1,'demo','Cleartext-Password',':=','demo'),(2,'CVXKGT','Cleartext-Password',':=','CVXKGT'),(4,'CVXKGT','Max-All-Session',':=','60'),(5,'CVXKGT','Expire-After',':=','120'),(6,'C5BAT','Cleartext-Password',':=','C5BAT'),(8,'C5BAT','Max-All-Session',':=','60'),(9,'C5BAT','Expire-After',':=','120');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
INSERT INTO `radgroupcheck` VALUES (1,'silver','Simultaneous-Use',':=','1');
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
INSERT INTO `radgroupreply` VALUES (1,'silver','MikroTik-Rate-Limit',':=','10M/10M'),(2,'silver','Framed-Pool',':=','POOL-PPPoE'),(3,'paket-2000','MikroTik-Rate-Limit',':=','10M/10M');
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  `reply` varchar(32) NOT NULL DEFAULT '',
  `authdate` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `class` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `class` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
INSERT INTO `radpostauth` VALUES (1,'demo','demo','Access-Accept','2025-11-28 06:31:41.028839',NULL),(2,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:11:39.187154',NULL),(3,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:11:47.300261',NULL),(4,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:12:26.269685',NULL),(5,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:12:42.575567',NULL),(6,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:12:58.666100',NULL),(7,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:13:17.550905',NULL),(8,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:13:31.431199',NULL),(9,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:15:19.047367',NULL),(10,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:15:37.768048',NULL),(11,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:16:22.424549',NULL),(12,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:16:42.245543',NULL),(13,'CVXKGT','0xe86cc2319436b049faacb3a0f4502ea975','Access-Accept','2025-12-08 15:17:14.172483',NULL),(14,'CVXKGT','0xe86cc2319436b049faacb3a0f4502ea975','Access-Accept','2025-12-08 15:18:38.564378',NULL),(15,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:20:23.971194',NULL),(16,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:20:40.786890',NULL),(17,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:23:22.891714',NULL),(18,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:23:22.891714',NULL),(19,'CVXKGT','0xba0ba5aed9fd946c07b2e321f5a4644e80','Access-Accept','2025-12-08 15:23:33.584108',NULL),(20,'CVXKGT','0xba0ba5aed9fd946c07b2e321f5a4644e80','Access-Reject','2025-12-08 15:23:33.584108',NULL),(21,'CVXKGT','0xda6e9e562ed08340371e8d28149d4a7026','Access-Accept','2025-12-08 15:23:49.044565',NULL),(22,'CVXKGT','0xda6e9e562ed08340371e8d28149d4a7026','Access-Reject','2025-12-08 15:23:49.044565',NULL),(23,'CVXKGT','0xbba999baed75db3acd7556eaaeb8d54a06','Access-Accept','2025-12-08 15:24:12.284542',NULL),(24,'CVXKGT','0xbba999baed75db3acd7556eaaeb8d54a06','Access-Reject','2025-12-08 15:24:12.284542',NULL),(25,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Accept','2025-12-08 15:24:56.996260',NULL),(26,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Accept','2025-12-08 15:26:09.856274',NULL),(27,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Reject','2025-12-08 15:26:09.856274',NULL),(28,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Accept','2025-12-08 15:26:31.976213',NULL),(29,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Reject','2025-12-08 15:26:31.976213',NULL),(30,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Accept','2025-12-08 15:26:48.070840',NULL),(31,'C5BAT','0xe9efd4a65c610bc75500d724fd95e25322','Access-Reject','2025-12-08 15:26:48.070840',NULL),(32,'C5BAT','0x97faf9df85847d9767e02b52f9601e6e49','Access-Accept','2025-12-08 15:27:17.464374',NULL),(33,'C5BAT','0x97faf9df85847d9767e02b52f9601e6e49','Access-Reject','2025-12-08 15:27:17.464374',NULL),(34,'C5BAT','C5BAT','Access-Reject','2025-12-08 15:27:53.913376',NULL),(35,'C5BAT','0xd7d81352ba72366238396872e12fe4f83c','Access-Accept','2025-12-08 15:30:01.849525',NULL),(36,'C5BAT','0xd7d81352ba72366238396872e12fe4f83c','Access-Reject','2025-12-08 15:30:01.849525',NULL),(37,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:30:02.215363',NULL),(38,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:30:02.215363',NULL),(39,'C5BAT','C5BAT','Access-Reject','2025-12-08 15:30:22.547024',NULL),(40,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:30:29.478850',NULL),(41,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:30:29.478850',NULL),(42,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:30:34.944171',NULL),(43,'CVXKGT','CVXKGT','Access-Reject','2025-12-08 15:30:34.944171',NULL),(44,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:31:29.670268',NULL),(45,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 15:31:43.971044',NULL),(46,'C5BAT','0x7168781b0159c44c808221c9bd180e79a0','Access-Accept','2025-12-08 15:32:49.499803',NULL),(47,'C5BAT','0xa87d28054d51f25270260291ca8b867931','Access-Accept','2025-12-08 15:33:01.192159',NULL),(48,'C5BAT','0x7ef3612bbc561c7975f93e2e32434231af','Access-Accept','2025-12-08 16:04:26.707638',NULL),(49,'CVXKGT','CVXKGT','Access-Accept','2025-12-08 16:05:21.600864',NULL),(50,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:08:07.070251',NULL),(51,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:24:32.399902',NULL),(52,'C5BAT','0xa8597771648b047aaf766878fa43bda3b0','Access-Accept','2025-12-08 16:25:03.022312',NULL),(53,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:26:34.743598',NULL),(54,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:28:07.453439',NULL),(55,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:28:30.033827',NULL),(56,'C5BAT','0x36106e89ac77e1c7963dd68f645e284507','Access-Accept','2025-12-08 16:29:16.463637',NULL),(57,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:31:02.789282',NULL),(58,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:34:53.593911',NULL),(59,'C5BAT','0xf214f53c002e8ba9ceb7d3c582cdd1f04e','Access-Accept','2025-12-08 16:36:45.838451',NULL),(60,'C5BAT','C5BAT','Access-Accept','2025-12-08 16:46:42.101336',NULL);
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
INSERT INTO `radreply` VALUES (1,'CVXKGT','Reply-Message',':=','voucher'),(2,'CVXKGT','Mikrotik-Server',':=','Income'),(3,'CVXKGT','Session-Timeout',':=','60'),(4,'C5BAT','Reply-Message',':=','voucher'),(5,'C5BAT','Mikrotik-Server',':=','Income'),(6,'C5BAT','Session-Timeout',':=','60');
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radusergroup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES (1,'demo','silver',1),(2,'CVXKGT','paket-2000',1),(3,'C5BAT','Paket-2000',1);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08 19:20:24
